# Data-Visualization
This project aims to create a comprehensive data visualization dashboard using the given jsondata.json file.Backend with Django, frontend with Bootstrap and  React. Visualizations using D3.js, Features filters for year, topics, sector, region, country, and city. Reads data from the database via Python API.

![image](https://github.com/user-attachments/assets/abf415b7-bc96-4ec2-8a9b-a8ac563ca712)
![image](https://github.com/user-attachments/assets/2a36b66b-4c62-4b30-b6a0-18ba61979f8a)

![image](https://github.com/user-attachments/assets/56e27be4-d574-42f6-8a33-84b53b4c448c)

![likelikhood](https://github.com/user-attachments/assets/d280644f-4a20-4968-bc3c-463a17916ebc)

![pie chart](https://github.com/user-attachments/assets/0e3b95e0-ae28-4077-ba8f-b6e0cade7f9f)

<img width="953" alt="graph2" src="https://github.com/user-attachments/assets/eb25f1cc-104d-44c5-8a4e-29397c060cdb">


